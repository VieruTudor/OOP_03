#pragma once
#include "Domain.h"
typedef struct {
	int size;
	int capacity;
	Product* elements;
}DynamicArray;

DynamicArray* createDynamicArray(int capacity);
void resizeDynamicArray(DynamicArray* dynamicArray);
void destroyDynamicArray(DynamicArray* dynamicArray, Product product);
void addElementDynamicArray(DynamicArray* dynamicArray, Product product);
void removeElementFromIndex(DynamicArray* dynamicArray, int index);
void updateElementAtIndex(DynamicArray* dynamicArray, int index, Product newProduct);
Product getElement(DynamicArray* dynamicArray, int index);
DynamicArray* getCopy(DynamicArray* dynamicArray);
int size(DynamicArray* dynamicArray);
