#include "Repo.h"
#include <stdio.h>
#include <stdlib.h>

Repository* createRepo(int capacity)
{
	Repository* repo;
	repo = (Repository*)malloc(sizeof(Repository));
	repo->productList = createDynamicArray(capacity);
	return repo;
}

void destroyRepo(Repository* repository)
{
	free(repository);
}

int searchProductRepo(Repository* repository, Product product)
{
	int index;
	for (index = 0; index < repository->productList->size; index++)
		if (getElement(repository->productList, index).catalogueNumber == product.catalogueNumber)
			return index;
	return -1;
}

int addProductRepo(Repository* repository, Product product)
{
	int productIndex;
	productIndex = searchProductRepo(repository, product);
	if (productIndex != -1)
		return productIndex;
	addElementDynamicArray(repository->productList, product);
	return -1;
}

int deleteProductRepo(Repository* repository, Product product)
{
	int productIndex;
	productIndex = searchProductRepo(repository, product);
	if (productIndex == -1)
		return productIndex;
	removeElementFromIndex(repository->productList, productIndex);
}

int updateProductRepo(Repository* repository, Product oldProduct, Product newProduct)
{
	int productIndex;
	productIndex = searchProductRepo(repository, oldProduct);
	if (productIndex == -1)
		return productIndex;
	updateElementAtIndex(repository->productList, productIndex, newProduct);
	return productIndex;
}

Product* getAllElementsRepo(Repository* repository)
{
	return repository->productList->elements;
}

int getSizeRepo(Repository* repository)
{
	return repository->productList->size;
}
