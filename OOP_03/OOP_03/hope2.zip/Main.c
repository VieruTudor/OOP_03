#include "Repo.h"
#include "Controller.h"
#include "UI.h"

int main()
{
	Repository* repository;
	repository = createRepo();
	Controller* controller;
	controller = createController(repository);
	UI* ui;
	ui = createUI(controller);
	run(ui);
	return 0;
}