#include "Repo.h"
#include <stdio.h>
#include <stdlib.h>

Repository* createRepo()
{
	Repository* repo;
	repo = (Repository*)malloc(sizeof(Repository));
	if (repo == NULL)
		return NULL;
	repo->arrayLength = 0;
	return repo;
}

void destroyRepo(Repository* repository)
{
	free(repository);
}

int searchProductRepo(Repository* repository, Product product)
{
	int index;
	for (index = 0; index < repository->arrayLength; index++)
		if (repository->productArray[index].catalogueNumber == product.catalogueNumber)
			return index;
	return -1;
}

int addProductRepo(Repository* repository, Product product)
{
	int productIndex;
	productIndex = searchProductRepo(repository, product);
	if (productIndex != -1)
		return productIndex;
	repository->productArray[repository->arrayLength] = product;
	repository->arrayLength++;
	return -1;
}

int deleteProductRepo(Repository* repository, Product product)
{
	int productIndex, i;
	productIndex = searchProductRepo(repository, product);
	if (productIndex == -1)
		return productIndex;
	for (i = productIndex; i < repository->arrayLength - 1; i++)
		repository->productArray[i] = repository->productArray[i + 1];
	repository->arrayLength--;
}

int updateProductRepo(Repository* repository, Product oldProduct, Product newProduct)
{
	int productIndex;
	productIndex = searchProductRepo(repository, oldProduct);
	if (productIndex == -1)
		return productIndex;
	repository->productArray[productIndex] = newProduct;
	return productIndex;
}
