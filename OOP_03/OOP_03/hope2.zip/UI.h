#pragma once

#include "Controller.h"

typedef struct {
	Controller* controller;
}UI;

UI* createUI(Controller* controller);
void destroyUI(UI* ui);
void addProductUI(UI* ui, int catalogueNumber, char* state, char* type, int value);
void deleteProductUI(UI* ui, int catalogueNumber);
void updateProductUI(UI* ui, int catalogueNumber, char* newState, char* newType, int newValue);
void listProducts(UI* ui);
void listProductsOfType(UI* ui, char* type);

void readAddCommand(UI* ui, int* catalogueNumber, char* state, char* type, int* value);
void readUpdateCommand(UI* ui, int* catalogueNumber, char* newState, char* newType, int* newValue);
void readDeleteCommand(UI* ui, int* catalogueNumber);
void readListTypeCommand(UI* ui, char* type);
int readUserCommand(UI* ui);
void run(UI* ui);


