#include "Controller.h"
#include "Repo.h"
#include <string.h>
#include <stdlib.h>

Controller* createController(Repository* repository)
{
	Controller* controller;
	controller = (Controller*)malloc(sizeof(Controller));
	controller->repository = repository;
	controller->productList = repository->productArray;
	controller->productListLength = repository->arrayLength;
	return controller;
}

void destroyController(Controller* controller)
{
	free(controller);
}

int addProductController(Controller* controller, int catalogueNumber, char* state, char* type, int value)
{
	Product addedProduct;
	addedProduct = createProduct(catalogueNumber, state, type, value);
	return addProductRepo(controller->repository, addedProduct);
}

int deleteProductController(Controller* controller, int catalogueNumber)
{
	Product deletedProduct = createProduct(catalogueNumber, "", "", 0);
	return deleteProductRepo(controller->repository, deletedProduct);
}

int updateProductController(Controller* controller, int catalogueNumber, char* newState, char* newType, int newValue)
{
	Product oldProduct = createProduct(catalogueNumber, "", "", 0);
	Product newProduct = createProduct(catalogueNumber, newState, newType, newValue);
	return updateProductRepo(controller->repository, oldProduct, newProduct);
}

Product* getAllProducts(Controller* controller)
{
	return controller->repository->productArray;
}

int getProductsLength(Controller* controller)
{
	return controller->repository->arrayLength;
}
