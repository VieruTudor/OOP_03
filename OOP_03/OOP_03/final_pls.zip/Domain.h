#pragma once

#include <string.h>
#include <stdlib.h>

typedef struct {
	int catalogueNumber;
	char state[30];
	char type[30];
	int value;
}Product;


Product createProduct(int catalogueNumber, char* state, char* type, int value);
void destroyProduct(Product* product);
int getCatalogueNumber(Product* product);
char* getState(Product* product);
char* getType(Product* product);
int getValue(Product* product);


