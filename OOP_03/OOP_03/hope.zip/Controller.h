#pragma once

#include "Repo.h"

typedef struct {
	Repository* repository;
	Product* productList;
	int productListLength;
}Controller;

Controller* createController(Repository* repository);
void destroyController(Controller* controller);
int addProductController(Controller* controller, int catalogueNumber, char* state, char* type, int value);
int deleteProductController(Controller* controller, int catalogueNumber);
int updateProductController(Controller* controller, int catalogueNumber, char* newState, char* newType, int newValue);
