#pragma once

#include "Domain.h"

typedef struct {
	Product productArray[1005];
	int arrayLength;
}Repository;

Repository* createRepo();
void destroyRepo(Repository* repository);
int searchProductRepo(Repository* repository, Product product);
int addProductRepo(Repository* repository, Product product);
int deleteProductRepo(Repository* repository, Product product);
int updateProductRepo(Repository* repository, Product oldProduct, Product newProduct);
